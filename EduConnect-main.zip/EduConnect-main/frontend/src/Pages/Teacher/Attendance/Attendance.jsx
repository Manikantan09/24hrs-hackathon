import GetSubject from "../GetSubject/GetSubject";

export default function Attendance() {
  return (
    <>
      <GetSubject />
    </>
  );
}
