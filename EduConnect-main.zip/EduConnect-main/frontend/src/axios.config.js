import axios from "axios";

axios.defaults.baseURL = "http://educonnect-backend.ap-southeast-1.elasticbeanstalk.com/"