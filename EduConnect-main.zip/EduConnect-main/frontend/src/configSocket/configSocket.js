const config = {
  serverUrl: "http://educonnect-backend.ap-southeast-1.elasticbeanstalk.com/",
};

export default config;
